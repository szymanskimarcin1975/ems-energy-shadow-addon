#!/bin/sh
set -eu
cd "$(dirname "$0")"
[ "${1:-}" = apply ] || { echo USE_VERIFIED_PREPARE_AND_MANUAL_ACK; exit 1; }
exec sh manual-ack-launch.sh "${2:-}"
